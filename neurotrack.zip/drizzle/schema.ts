import {
  int,
  mysqlEnum,
  mysqlTable,
  text,
  timestamp,
  varchar,
  decimal,
  boolean,
  date,
  time,
} from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with NeuroTrack-specific fields.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  
  // NeuroTrack specific fields
  currentLevel: int("currentLevel").default(1).notNull(),
  currentXP: int("currentXP").default(0).notNull(),
  totalXPEarned: int("totalXPEarned").default(0).notNull(),
  totalHabitsCreated: int("totalHabitsCreated").default(0).notNull(),
  totalDaysTracked: int("totalDaysTracked").default(0).notNull(),
  consistencyPercentage: decimal("consistencyPercentage", { precision: 5, scale: 2 }).default("0.00").notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Habits table - stores all user habits
 */
export const habits = mysqlTable("habits", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  name: varchar("name", { length: 255 }).notNull(),
  description: text("description"),
  category: mysqlEnum("category", [
    "Health",
    "Productivity",
    "Mindfulness",
    "Fitness",
    "Study",
    "Custom",
  ]).default("Custom").notNull(),
  
  // Habit type: daily, duration-based, or flexible
  type: mysqlEnum("type", ["daily", "duration", "flexible"]).default("daily").notNull(),
  
  // For duration-based habits
  startDate: date("startDate"),
  endDate: date("endDate"),
  
  // For flexible habits (e.g., 3 times per week)
  frequency: int("frequency"), // e.g., 3
  frequencyUnit: mysqlEnum("frequencyUnit", ["day", "week", "month"]), // e.g., "week"
  
  difficulty: mysqlEnum("difficulty", ["Easy", "Medium", "Hard"]).default("Easy").notNull(),
  
  // Reminder settings
  reminderEnabled: boolean("reminderEnabled").default(false).notNull(),
  reminderTime: time("reminderTime"),
  
  // Tracking
  isActive: boolean("isActive").default(true).notNull(),
  xpReward: int("xpReward").default(10).notNull(),
  
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Habit = typeof habits.$inferSelect;
export type InsertHabit = typeof habits.$inferInsert;

/**
 * Habit completions - daily tracking of habit completion
 */
export const habitCompletions = mysqlTable("habitCompletions", {
  id: int("id").autoincrement().primaryKey(),
  habitId: int("habitId").notNull(),
  userId: int("userId").notNull(),
  completionDate: date("completionDate").notNull(),
  completed: boolean("completed").default(false).notNull(),
  notes: text("notes"),
  xpEarned: int("xpEarned").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type HabitCompletion = typeof habitCompletions.$inferSelect;
export type InsertHabitCompletion = typeof habitCompletions.$inferInsert;

/**
 * Streaks table - tracks current and longest streaks for habits
 */
export const streaks = mysqlTable("streaks", {
  id: int("id").autoincrement().primaryKey(),
  habitId: int("habitId").notNull(),
  userId: int("userId").notNull(),
  currentStreak: int("currentStreak").default(0).notNull(),
  longestStreak: int("longestStreak").default(0).notNull(),
  lastCompletionDate: date("lastCompletionDate"),
  streakStartDate: date("streakStartDate"),
  isAtRisk: boolean("isAtRisk").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Streak = typeof streaks.$inferSelect;
export type InsertStreak = typeof streaks.$inferInsert;

/**
 * Achievements/Badges table - tracks unlocked badges
 */
export const achievements = mysqlTable("achievements", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  badgeType: mysqlEnum("badgeType", [
    "7DayStarter",
    "30DayDisciplined",
    "90DayIronMind",
    "PerfectWeek",
    "MonthMaster",
    "TripleStreak",
    "LevelUp5",
    "LevelUp10",
    "XPMaster",
    "HabitHero",
  ]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: text("description"),
  unlockedAt: timestamp("unlockedAt").defaultNow().notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Achievement = typeof achievements.$inferSelect;
export type InsertAchievement = typeof achievements.$inferInsert;

/**
 * Notifications table - for reminders and celebrations
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  type: mysqlEnum("type", [
    "reminder",
    "streakMilestone",
    "levelUp",
    "badgeUnlocked",
    "streakAtRisk",
  ]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message").notNull(),
  habitId: int("habitId"),
  read: boolean("read").default(false).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * AI usage tracking - to enforce daily limits
 */
export const aiUsage = mysqlTable("aiUsage", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  requestDate: date("requestDate").notNull(),
  requestCount: int("requestCount").default(1).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type AIUsage = typeof aiUsage.$inferSelect;
export type InsertAIUsage = typeof aiUsage.$inferInsert;

/**
 * Habit tags table - for organizing habits
 */
export const habitTags = mysqlTable("habitTags", {
  id: int("id").autoincrement().primaryKey(),
  habitId: int("habitId").notNull(),
  tag: varchar("tag", { length: 100 }).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type HabitTag = typeof habitTags.$inferSelect;
export type InsertHabitTag = typeof habitTags.$inferInsert;
