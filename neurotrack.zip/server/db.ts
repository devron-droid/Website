import { eq, and, gte, lte, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser,
  users,
  habits,
  habitCompletions,
  streaks,
  achievements,
  notifications,
  aiUsage,
} from "../drizzle/schema";
import { ENV } from "./_core/env";

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = "admin";
      updateSet.role = "admin";
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db
    .select()
    .from(users)
    .where(eq(users.openId, openId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function getUserById(userId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(users)
    .where(eq(users.id, userId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// Habit queries
export async function getUserHabits(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db.select().from(habits).where(eq(habits.userId, userId));
}

export async function getHabitById(habitId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(habits)
    .where(eq(habits.id, habitId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createHabit(habitData: typeof habits.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const result = await db.insert(habits).values(habitData);
  return result;
}

export async function updateHabit(
  habitId: number,
  updates: Partial<typeof habits.$inferInsert>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(habits)
    .set(updates)
    .where(eq(habits.id, habitId));
}

export async function deleteHabit(habitId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.delete(habits).where(eq(habits.id, habitId));
}

// Habit completion queries
export async function getHabitCompletions(
  habitId: number,
  startDate?: Date,
  endDate?: Date
) {
  const db = await getDb();
  if (!db) return [];

  if (startDate && endDate) {
    return await db
      .select()
      .from(habitCompletions)
      .where(
        and(
          eq(habitCompletions.habitId, habitId),
          gte(habitCompletions.completionDate, startDate),
          lte(habitCompletions.completionDate, endDate)
        )
      );
  }

  return await db
    .select()
    .from(habitCompletions)
    .where(eq(habitCompletions.habitId, habitId));
}

export async function getOrCreateCompletion(
  habitId: number,
  userId: number,
  completionDate: Date
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const existing = await db
    .select()
    .from(habitCompletions)
    .where(
      and(
        eq(habitCompletions.habitId, habitId),
        eq(habitCompletions.completionDate, completionDate)
      )
    )
    .limit(1);

  if (existing.length > 0) {
    return existing[0];
  }

  const result = await db.insert(habitCompletions).values({
    habitId,
    userId,
    completionDate,
    completed: false,
    xpEarned: 0,
  });

  return { habitId, userId, completionDate, completed: false, xpEarned: 0 };
}

export async function updateCompletion(
  completionId: number,
  updates: Partial<typeof habitCompletions.$inferInsert>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(habitCompletions)
    .set(updates)
    .where(eq(habitCompletions.id, completionId));
}

// Streak queries
export async function getStreakByHabit(habitId: number) {
  const db = await getDb();
  if (!db) return undefined;

  const result = await db
    .select()
    .from(streaks)
    .where(eq(streaks.habitId, habitId))
    .limit(1);

  return result.length > 0 ? result[0] : undefined;
}

export async function createStreak(streakData: typeof streaks.$inferInsert) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(streaks).values(streakData);
}

export async function updateStreak(
  streakId: number,
  updates: Partial<typeof streaks.$inferInsert>
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(streaks)
    .set(updates)
    .where(eq(streaks.id, streakId));
}

// Achievement queries
export async function getUserAchievements(userId: number) {
  const db = await getDb();
  if (!db) return [];

  return await db
    .select()
    .from(achievements)
    .where(eq(achievements.userId, userId))
    .orderBy(desc(achievements.unlockedAt));
}

export async function createAchievement(
  achievementData: typeof achievements.$inferInsert
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(achievements).values(achievementData);
}

// Notification queries
export async function getUserNotifications(userId: number, unreadOnly = false) {
  const db = await getDb();
  if (!db) return [];

  if (unreadOnly) {
    return await db
      .select()
      .from(notifications)
      .where(
        and(
          eq(notifications.userId, userId),
          eq(notifications.read, false)
        )
      )
      .orderBy(desc(notifications.createdAt));
  }

  return await db
    .select()
    .from(notifications)
    .where(eq(notifications.userId, userId))
    .orderBy(desc(notifications.createdAt));
}

export async function createNotification(
  notificationData: typeof notifications.$inferInsert
) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db.insert(notifications).values(notificationData);
}

export async function markNotificationRead(notificationId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  return await db
    .update(notifications)
    .set({ read: true })
    .where(eq(notifications.id, notificationId));
}

// AI usage queries
export async function getAIUsageToday(userId: number) {
  const db = await getDb();
  if (!db) return null;

  const today = new Date().toISOString().split("T")[0];

  const result = await db
    .select()
    .from(aiUsage)
    .where(
      and(
        eq(aiUsage.userId, userId),
        eq(aiUsage.requestDate, new Date(today))
      )
    )
    .limit(1);

  return result.length > 0 ? result[0] : null;
}

export async function incrementAIUsage(userId: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");

  const today = new Date().toISOString().split("T")[0];
  const existing = await getAIUsageToday(userId);

  if (existing) {
    return await db
      .update(aiUsage)
      .set({ requestCount: existing.requestCount + 1 })
      .where(eq(aiUsage.id, existing.id));
  } else {
    return await db.insert(aiUsage).values({
      userId,
      requestDate: today as any,
      requestCount: 1,
    });
  }
}
