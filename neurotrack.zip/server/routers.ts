import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import {
  getUserHabits,
  getHabitById,
  createHabit,
  updateHabit,
  deleteHabit,
  getHabitCompletions,
  getOrCreateCompletion,
  updateCompletion,
  getStreakByHabit,
  createStreak,
  updateStreak,
  getUserAchievements,
  createAchievement,
  getUserNotifications,
  createNotification,
  getAIUsageToday,
  incrementAIUsage,
  getUserById,
} from "./db";
import { z } from "zod";
import { TRPCError } from "@trpc/server";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query((opts) => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return {
        success: true,
      } as const;
    }),
  }),

  // Habits management
  habits: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await getUserHabits(ctx.user.id);
    }),

    get: protectedProcedure
      .input(z.object({ habitId: z.number() }))
      .query(async ({ input }) => {
        const habit = await getHabitById(input.habitId);
        if (!habit) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }
        return habit;
      }),

    create: protectedProcedure
      .input(
        z.object({
          name: z.string().min(1).max(255),
          description: z.string().optional(),
          category: z.enum([
            "Health",
            "Productivity",
            "Mindfulness",
            "Fitness",
            "Study",
            "Custom",
          ]),
          type: z.enum(["daily", "duration", "flexible"]),
          difficulty: z.enum(["Easy", "Medium", "Hard"]),
          xpReward: z.number().default(10),
          startDate: z.date().optional(),
          endDate: z.date().optional(),
          frequency: z.number().optional(),
          frequencyUnit: z.enum(["day", "week", "month"]).optional(),
          reminderEnabled: z.boolean().default(false),
          reminderTime: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const habit = await createHabit({
          userId: ctx.user.id,
          name: input.name,
          description: input.description,
          category: input.category,
          type: input.type,
          difficulty: input.difficulty,
          xpReward: input.xpReward,
          startDate: input.startDate,
          endDate: input.endDate,
          frequency: input.frequency,
          frequencyUnit: input.frequencyUnit,
          reminderEnabled: input.reminderEnabled,
          reminderTime: input.reminderTime as any,
        });

        // Create initial streak record
        await createStreak({
          habitId: 0,
          userId: ctx.user.id,
          currentStreak: 0,
          longestStreak: 0,
        });

        return habit;
      }),

    update: protectedProcedure
      .input(
        z.object({
          habitId: z.number(),
          name: z.string().optional(),
          description: z.string().optional(),
          category: z
            .enum([
              "Health",
              "Productivity",
              "Mindfulness",
              "Fitness",
              "Study",
              "Custom",
            ])
            .optional(),
          difficulty: z.enum(["Easy", "Medium", "Hard"]).optional(),
          xpReward: z.number().optional(),
          isActive: z.boolean().optional(),
        })
      )
      .mutation(async ({ input }) => {
        return await updateHabit(input.habitId, {
          name: input.name,
          description: input.description,
          category: input.category,
          difficulty: input.difficulty,
          xpReward: input.xpReward,
          isActive: input.isActive,
        });
      }),

    delete: protectedProcedure
      .input(z.object({ habitId: z.number() }))
      .mutation(async ({ input }) => {
        return await deleteHabit(input.habitId);
      }),
  }),

  // Habit completions
  completions: router({
    list: protectedProcedure
      .input(
        z.object({
          habitId: z.number(),
          startDate: z.date().optional(),
          endDate: z.date().optional(),
        })
      )
      .query(async ({ input }) => {
        return await getHabitCompletions(
          input.habitId,
          input.startDate,
          input.endDate
        );
      }),

    toggle: protectedProcedure
      .input(
        z.object({
          habitId: z.number(),
          completionDate: z.date(),
          completed: z.boolean(),
          xpEarned: z.number().optional(),
          notes: z.string().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const completion = await getOrCreateCompletion(
          input.habitId,
          ctx.user.id,
          input.completionDate
        );

        // Update the completion
        const result = await updateCompletion((completion as any).id, {
          completed: input.completed,
          xpEarned: input.xpEarned || 0,
          notes: input.notes,
        });

        // Update user XP if completed
        if (input.completed && input.xpEarned) {
          const user = await getUserById(ctx.user.id);
          if (user) {
            const newXP = user.currentXP + input.xpEarned;
            const newLevel = Math.floor(newXP / 100) + 1;

            // Update user in database
            // This would need to be added to db.ts
          }
        }

        return result;
      }),
  }),

  // Streaks
  streaks: router({
    get: protectedProcedure
      .input(z.object({ habitId: z.number() }))
      .query(async ({ input }) => {
        return await getStreakByHabit(input.habitId);
      }),

    calculateStreak: protectedProcedure
      .input(z.object({ habitId: z.number() }))
      .query(async ({ input }) => {
        const completions = await getHabitCompletions(input.habitId);
        const streak = await getStreakByHabit(input.habitId);

        if (!streak) {
          throw new TRPCError({ code: "NOT_FOUND" });
        }

        // Sort completions by date
        const sorted = completions
          .filter((c) => c.completed)
          .sort(
            (a, b) =>
              new Date(a.completionDate).getTime() -
              new Date(b.completionDate).getTime()
          );

        // Calculate current streak
        let currentStreak = 0;
        if (sorted.length > 0) {
          const today = new Date();
          today.setHours(0, 0, 0, 0);

          let checkDate = new Date(today);
          for (let i = sorted.length - 1; i >= 0; i--) {
            const completionDate = new Date(sorted[i].completionDate);
            completionDate.setHours(0, 0, 0, 0);

            if (
              completionDate.getTime() === checkDate.getTime() ||
              completionDate.getTime() === checkDate.getTime() - 86400000
            ) {
              currentStreak++;
              checkDate.setDate(checkDate.getDate() - 1);
            } else {
              break;
            }
          }
        }

        return {
          currentStreak,
          longestStreak: streak.longestStreak,
          lastCompletionDate: streak.lastCompletionDate,
        };
      }),
  }),

  // Achievements
  achievements: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await getUserAchievements(ctx.user.id);
    }),

    check: protectedProcedure
      .input(z.object({ habitId: z.number() }))
      .mutation(async ({ ctx, input }) => {
        const streak = await getStreakByHabit(input.habitId);
        if (!streak) return null;

        const achievements = [];

        if (streak.currentStreak === 7) {
          const achievement = await createAchievement({
            userId: ctx.user.id,
            badgeType: "7DayStarter",
            title: "7 Day Starter",
            description: "Completed a 7-day streak",
          });
          achievements.push(achievement);
        }

        if (streak.currentStreak === 30) {
          const achievement = await createAchievement({
            userId: ctx.user.id,
            badgeType: "30DayDisciplined",
            title: "30 Day Disciplined",
            description: "Completed a 30-day streak",
          });
          achievements.push(achievement);
        }

        if (streak.currentStreak === 90) {
          const achievement = await createAchievement({
            userId: ctx.user.id,
            badgeType: "90DayIronMind",
            title: "90 Day Iron Mind",
            description: "Completed a 90-day streak",
          });
          achievements.push(achievement);
        }

        return achievements;
      }),
  }),

  // Notifications
  notifications: router({
    list: protectedProcedure
      .input(z.object({ unreadOnly: z.boolean().optional() }))
      .query(async ({ ctx, input }) => {
        return await getUserNotifications(ctx.user.id, input?.unreadOnly);
      }),

    create: protectedProcedure
      .input(
        z.object({
          type: z.enum([
            "reminder",
            "streakMilestone",
            "levelUp",
            "badgeUnlocked",
            "streakAtRisk",
          ]),
          title: z.string(),
          message: z.string(),
          habitId: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        return await createNotification({
          userId: ctx.user.id,
          type: input.type,
          title: input.title,
          message: input.message,
          habitId: input.habitId,
        });
      }),
  }),

  // AI Integration
  ai: router({
    checkUsage: protectedProcedure.query(async ({ ctx }) => {
      const usage = await getAIUsageToday(ctx.user.id);
      return {
        requestsUsed: usage?.requestCount || 0,
        requestsRemaining: Math.max(0, 5 - (usage?.requestCount || 0)),
        canMakeRequest: (usage?.requestCount || 0) < 5,
      };
    }),

    chat: protectedProcedure
      .input(
        z.object({
          message: z.string(),
          type: z.enum(["advisor", "builder"]),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const usage = await getAIUsageToday(ctx.user.id);
        if ((usage?.requestCount || 0) >= 5) {
          throw new TRPCError({
            code: "FORBIDDEN",
            message: "Daily AI request limit reached (5 per day)",
          });
        }

        // Increment usage
        await incrementAIUsage(ctx.user.id);

        // TODO: Call OpenAI API here
        return {
          response: "AI response placeholder",
        };
      }),
  }),
});

export type AppRouter = typeof appRouter;
