import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { getLoginUrl } from "@/const";
import { motion } from "framer-motion";
import { Zap, Target, Trophy, Flame, Brain, ArrowRight } from "lucide-react";

export default function Home() {
  const { isAuthenticated } = useAuth();

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <div className="cosmic-bg min-h-screen overflow-hidden">
      {/* Animated background nebulas */}
      <div className="fixed inset-0 pointer-events-none">
        <div className="nebula-glow w-96 h-96 top-20 left-10 animate-pulse" />
        <div className="nebula-glow w-96 h-96 bottom-10 right-20 animate-pulse" style={{ animationDelay: "1.5s" }} />
        <div className="nebula-glow w-64 h-64 top-1/2 left-1/2 animate-pulse" style={{ animationDelay: "0.75s" }} />
      </div>

      {/* Starfield background */}
      <div className="cosmic-bg::before fixed inset-0 pointer-events-none" />

      {/* Content */}
      <div className="relative z-10">
        {/* Navigation */}
        <header className="border-b border-primary/10 backdrop-blur-md">
          <div className="container py-4 flex justify-between items-center">
            <motion.div
              initial={{ opacity: 0, x: -20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.5 }}
            >
              <h1 className="text-2xl font-bold glow-text">NeuroTrack AI</h1>
              <p className="text-xs text-foreground/60">Made by Rudransh</p>
            </motion.div>
            {!isAuthenticated && (
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
              >
                Sign In
              </Button>
            )}
          </div>
        </header>

        {/* Hero section */}
        <main className="container py-20">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="max-w-4xl mx-auto text-center space-y-12"
          >
            {/* Main heading */}
            <motion.div variants={itemVariants} className="space-y-6">
              <h2 className="text-5xl md:text-6xl font-bold glow-text-lg leading-tight">
                Transform Your Habits Into Superpowers
              </h2>
              <p className="text-xl text-foreground/70 max-w-2xl mx-auto">
                Track daily habits, build unstoppable streaks, and level up your life with
                gamified motivation and AI-powered coaching.
              </p>
            </motion.div>

            {/* CTA Button */}
            <motion.div variants={itemVariants}>
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
                size="lg"
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 gap-2 text-lg px-8 py-6 animate-pulse-glow"
              >
                Start Your Journey
                <ArrowRight className="w-5 h-5" />
              </Button>
            </motion.div>

            {/* Features grid */}
            <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-3 gap-6 mt-16">
              {/* Feature 1 */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="cosmic-card cosmic-card-hover group"
              >
                <Flame className="w-12 h-12 text-accent mx-auto mb-4 group-hover:animate-bounce" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Build Streaks
                </h3>
                <p className="text-foreground/60">
                  Track daily habits and watch your streaks grow. Never break the chain!
                </p>
              </motion.div>

              {/* Feature 2 */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="cosmic-card cosmic-card-hover group"
              >
                <Zap className="w-12 h-12 text-accent mx-auto mb-4 group-hover:animate-bounce" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Earn XP & Level Up
                </h3>
                <p className="text-foreground/60">
                  Complete habits to earn XP, unlock achievements, and reach new levels.
                </p>
              </motion.div>

              {/* Feature 3 */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="cosmic-card cosmic-card-hover group"
              >
                <Brain className="w-12 h-12 text-accent mx-auto mb-4 group-hover:animate-bounce" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  AI Coaching
                </h3>
                <p className="text-foreground/60">
                  Get personalized advice and habit recommendations powered by AI.
                </p>
              </motion.div>

              {/* Feature 4 */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="cosmic-card cosmic-card-hover group"
              >
                <Target className="w-12 h-12 text-accent mx-auto mb-4 group-hover:animate-bounce" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Smart Tracking
                </h3>
                <p className="text-foreground/60">
                  Track daily, weekly, or flexible habits with customizable reminders.
                </p>
              </motion.div>

              {/* Feature 5 */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="cosmic-card cosmic-card-hover group"
              >
                <Trophy className="w-12 h-12 text-accent mx-auto mb-4 group-hover:animate-bounce" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Achievements
                </h3>
                <p className="text-foreground/60">
                  Unlock badges for milestones like 7-day, 30-day, and 90-day streaks.
                </p>
              </motion.div>

              {/* Feature 6 */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="cosmic-card cosmic-card-hover group"
              >
                <Flame className="w-12 h-12 text-accent mx-auto mb-4 group-hover:animate-bounce" />
                <h3 className="text-lg font-semibold text-foreground mb-2">
                  Analytics
                </h3>
                <p className="text-foreground/60">
                  Visualize your progress with detailed charts and consistency metrics.
                </p>
              </motion.div>
            </motion.div>

            {/* Stats section */}
            <motion.div variants={itemVariants} className="grid grid-cols-3 gap-6 mt-16 py-12 border-t border-primary/10">
              <div>
                <p className="text-3xl font-bold glow-text">100%</p>
                <p className="text-foreground/60 mt-2">Free Forever</p>
              </div>
              <div>
                <p className="text-3xl font-bold glow-text">∞</p>
                <p className="text-foreground/60 mt-2">Unlimited Habits</p>
              </div>
              <div>
                <p className="text-3xl font-bold glow-text">24/7</p>
                <p className="text-foreground/60 mt-2">Always Available</p>
              </div>
            </motion.div>

            {/* Final CTA */}
            <motion.div variants={itemVariants} className="space-y-4">
              <p className="text-lg text-foreground/70">
                Ready to transform your habits?
              </p>
              <Button
                onClick={() => (window.location.href = getLoginUrl())}
                size="lg"
                className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 gap-2 text-lg px-8 py-6"
              >
                Get Started Now
                <ArrowRight className="w-5 h-5" />
              </Button>
            </motion.div>
          </motion.div>
        </main>

        {/* Footer */}
        <footer className="border-t border-primary/10 backdrop-blur-md mt-20">
          <div className="container py-8 text-center text-foreground/60">
            <p>NeuroTrack AI • Made by Rudransh • All features are completely free</p>
          </div>
        </footer>
      </div>
    </div>
  );
}
