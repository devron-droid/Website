import { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Loader2, Send, Brain } from "lucide-react";
import { trpc } from "@/lib/trpc";
import { toast } from "sonner";

type Message = {
  id: string;
  role: "user" | "assistant";
  content: string;
  timestamp: Date;
};

export default function AICoach() {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      role: "assistant",
      content:
        "Hello! I'm your AI Habit Coach. I can help you build better habits, analyze your patterns, and provide personalized recommendations. What would you like to work on today?",
      timestamp: new Date(),
    },
  ]);
  const [input, setInput] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [chatType, setChatType] = useState<"advisor" | "builder">("advisor");

  const { data: usage } = trpc.ai.checkUsage.useQuery();
  const chatMutation = trpc.ai.chat.useMutation();

  const handleSendMessage = async () => {
    if (!input.trim() || isLoading) return;

    if (!usage?.canMakeRequest) {
      toast.error("Daily AI request limit reached (5 per day)");
      return;
    }

    const userMessage: Message = {
      id: Date.now().toString(),
      role: "user",
      content: input,
      timestamp: new Date(),
    };

    setMessages((prev) => [...prev, userMessage]);
    setInput("");
    setIsLoading(true);

    try {
      const response = await chatMutation.mutateAsync({
        message: input,
        type: chatType,
      });

      const assistantMessage: Message = {
        id: (Date.now() + 1).toString(),
        role: "assistant",
        content: response.response,
        timestamp: new Date(),
      };

      setMessages((prev) => [...prev, assistantMessage]);
    } catch (error) {
      toast.error("Failed to get AI response");
    } finally {
      setIsLoading(false);
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <div className="cosmic-bg min-h-screen py-12">
      <div className="fixed inset-0 pointer-events-none">
        <div className="nebula-glow w-96 h-96 top-10 left-10 animate-pulse" />
        <div className="nebula-glow w-96 h-96 bottom-20 right-20 animate-pulse" style={{ animationDelay: "1s" }} />
      </div>

      <div className="relative z-10 container max-w-2xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <div className="flex items-center gap-3 mb-4">
            <Brain className="w-8 h-8 text-accent" />
            <h1 className="text-4xl font-bold glow-text-lg">AI Habit Coach</h1>
          </div>
          <p className="text-foreground/60">
            Get personalized advice and habit recommendations
          </p>
        </motion.div>

        {/* Chat type selector */}
        <motion.div
          variants={itemVariants}
          initial="hidden"
          animate="visible"
          className="flex gap-4 mb-8"
        >
          <Button
            onClick={() => setChatType("advisor")}
            variant={chatType === "advisor" ? "default" : "outline"}
            className={
              chatType === "advisor"
                ? "bg-gradient-to-r from-cyan-500 to-blue-600"
                : "border-primary/30"
            }
          >
            Habit Advisor
          </Button>
          <Button
            onClick={() => setChatType("builder")}
            variant={chatType === "builder" ? "default" : "outline"}
            className={
              chatType === "builder"
                ? "bg-gradient-to-r from-cyan-500 to-blue-600"
                : "border-primary/30"
            }
          >
            Habit Builder
          </Button>
        </motion.div>

        {/* Usage indicator */}
        <motion.div
          variants={itemVariants}
          initial="hidden"
          animate="visible"
          className="mb-6"
        >
          <Card className="cosmic-card p-4">
            <p className="text-sm text-foreground/60">
              Daily requests: {usage?.requestsUsed || 0} / 5
            </p>
            <div className="w-full bg-card/60 rounded-full h-2 mt-2 overflow-hidden">
              <motion.div
                className="h-full bg-gradient-to-r from-cyan-400 to-blue-500"
                initial={{ width: 0 }}
                animate={{
                  width: `${((usage?.requestsUsed || 0) / 5) * 100}%`,
                }}
                transition={{ duration: 0.5 }}
              />
            </div>
          </Card>
        </motion.div>

        {/* Chat messages */}
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-4 mb-6 max-h-96 overflow-y-auto"
        >
          {messages.map((message) => (
            <motion.div
              key={message.id}
              variants={itemVariants}
              className={`flex ${
                message.role === "user" ? "justify-end" : "justify-start"
              }`}
            >
              <div
                className={`max-w-xs lg:max-w-md px-4 py-3 rounded-lg ${
                  message.role === "user"
                    ? "bg-gradient-to-r from-cyan-500/30 to-blue-600/30 border border-cyan-500/50"
                    : "cosmic-card"
                }`}
              >
                <p className="text-foreground text-sm">{message.content}</p>
                <p className="text-xs text-foreground/40 mt-2">
                  {message.timestamp.toLocaleTimeString()}
                </p>
              </div>
            </motion.div>
          ))}
          {isLoading && (
            <motion.div
              variants={itemVariants}
              className="flex justify-start"
            >
              <div className="cosmic-card px-4 py-3 rounded-lg">
                <Loader2 className="w-4 h-4 animate-spin text-accent" />
              </div>
            </motion.div>
          )}
        </motion.div>

        {/* Input area */}
        <motion.div
          variants={itemVariants}
          initial="hidden"
          animate="visible"
          className="cosmic-card p-4"
        >
          <div className="flex gap-2">
            <Input
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === "Enter" && handleSendMessage()}
              placeholder={
                chatType === "advisor"
                  ? "Ask for habit advice..."
                  : "Describe your goal..."
              }
              disabled={isLoading || !usage?.canMakeRequest}
              className="bg-card/60 border-primary/30 text-foreground placeholder:text-foreground/40"
            />
            <Button
              onClick={handleSendMessage}
              disabled={isLoading || !input.trim() || !usage?.canMakeRequest}
              className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700"
            >
              <Send className="w-4 h-4" />
            </Button>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
