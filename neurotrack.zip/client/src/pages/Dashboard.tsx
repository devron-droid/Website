import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Plus, Zap, Trophy, Flame, Target } from "lucide-react";
import { motion } from "framer-motion";
import { useEffect, useState } from "react";

export default function Dashboard() {
  const { user, logout } = useAuth();
  const [greeting, setGreeting] = useState("");

  // Fetch user habits
  const { data: habits, isLoading: habitsLoading } = trpc.habits.list.useQuery();

  // Fetch user achievements
  const { data: achievements } = trpc.achievements.list.useQuery();

  // Generate time-based greeting
  useEffect(() => {
    const hour = new Date().getHours();
    if (hour < 12) {
      setGreeting("Good Morning");
    } else if (hour < 18) {
      setGreeting("Good Afternoon");
    } else {
      setGreeting("Good Evening");
    }
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
        delayChildren: 0.2,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <div className="cosmic-bg min-h-screen">
      {/* Animated background nebulas */}
      <div className="fixed inset-0 pointer-events-none overflow-hidden">
        <div className="nebula-glow w-96 h-96 top-10 left-10 animate-pulse" />
        <div className="nebula-glow w-96 h-96 bottom-20 right-20 animate-pulse" style={{ animationDelay: "1s" }} />
      </div>

      {/* Main content */}
      <div className="relative z-10">
        {/* Header */}
        <header className="border-b border-primary/10 backdrop-blur-md sticky top-0 z-20">
          <div className="container py-6">
            <div className="flex justify-between items-center">
              <motion.div
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
              >
                <h1 className="text-3xl font-bold glow-text-lg">
                  {greeting}, {user?.name || "Adventurer"} 👋
                </h1>
                <p className="text-foreground/60 mt-1">Ready to level up today?</p>
              </motion.div>
              <Button
                variant="outline"
                onClick={logout}
                className="border-primary/30 hover:border-primary/60"
              >
                Logout
              </Button>
            </div>
          </div>
        </header>

        {/* Main dashboard */}
        <main className="container py-12">
          <motion.div
            variants={containerVariants}
            initial="hidden"
            animate="visible"
            className="space-y-8"
          >
            {/* Stats grid */}
            <motion.div variants={itemVariants} className="grid grid-cols-1 md:grid-cols-4 gap-6">
              {/* Level card */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="cosmic-card cosmic-card-hover group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-foreground/60 text-sm">Current Level</p>
                    <p className="text-4xl font-bold glow-text mt-2">
                      {user?.currentLevel || 1}
                    </p>
                  </div>
                  <Trophy className="w-12 h-12 text-accent opacity-60 group-hover:opacity-100 transition-opacity" />
                </div>
              </motion.div>

              {/* XP card */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="cosmic-card cosmic-card-hover group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-foreground/60 text-sm">Current XP</p>
                    <p className="text-4xl font-bold glow-text mt-2">
                      {user?.currentXP || 0}
                    </p>
                  </div>
                  <Zap className="w-12 h-12 text-accent opacity-60 group-hover:opacity-100 transition-opacity" />
                </div>
              </motion.div>

              {/* Consistency card */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="cosmic-card cosmic-card-hover group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-foreground/60 text-sm">Consistency</p>
                    <p className="text-4xl font-bold glow-text mt-2">
                      {user?.consistencyPercentage || 0}%
                    </p>
                  </div>
                  <Flame className="w-12 h-12 text-accent opacity-60 group-hover:opacity-100 transition-opacity" />
                </div>
              </motion.div>

              {/* Habits card */}
              <motion.div
                whileHover={{ scale: 1.05 }}
                className="cosmic-card cosmic-card-hover group"
              >
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-foreground/60 text-sm">Active Habits</p>
                    <p className="text-4xl font-bold glow-text mt-2">
                      {habits?.length || 0}
                    </p>
                  </div>
                  <Target className="w-12 h-12 text-accent opacity-60 group-hover:opacity-100 transition-opacity" />
                </div>
              </motion.div>
            </motion.div>

            {/* Today's habits section */}
            <motion.div variants={itemVariants}>
              <div className="flex justify-between items-center mb-6">
                <h2 className="text-2xl font-bold glow-text">Today's Habits</h2>
                <Button className="bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700 gap-2">
                  <Plus className="w-4 h-4" />
                  Add Habit
                </Button>
              </div>

              {habitsLoading ? (
                <div className="flex justify-center py-12">
                  <Loader2 className="w-8 h-8 animate-spin text-accent" />
                </div>
              ) : habits && habits.length > 0 ? (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  {habits.map((habit, index) => (
                    <motion.div
                      key={habit.id}
                      variants={itemVariants}
                      whileHover={{ scale: 1.02 }}
                      className="cosmic-card cosmic-card-hover group cursor-pointer"
                    >
                      <div className="flex justify-between items-start mb-4">
                        <div>
                          <h3 className="text-lg font-semibold text-foreground">
                            {habit.name}
                          </h3>
                          <p className="text-sm text-foreground/60 mt-1">
                            {habit.category} • {habit.difficulty}
                          </p>
                        </div>
                        <span className="px-3 py-1 rounded-full text-xs font-medium bg-accent/20 text-accent">
                          +{habit.xpReward} XP
                        </span>
                      </div>
                      <div className="w-full bg-card/60 rounded-full h-2 overflow-hidden">
                        <motion.div
                          className="h-full bg-gradient-to-r from-cyan-400 to-blue-500"
                      initial={{ width: 0 }}
                      animate={{ width: "45%" }}
                      transition={{ duration: 1 }}
                        />
                      </div>
                      <p className="text-xs text-foreground/50 mt-2">45% completed</p>
                    </motion.div>
                  ))}
                </div>
              ) : (
                <Card className="cosmic-card text-center py-12">
                  <p className="text-foreground/60">
                    No habits yet. Create your first habit to get started!
                  </p>
                </Card>
              )}
            </motion.div>

            {/* Achievements section */}
            {achievements && achievements.length > 0 && (
              <motion.div variants={itemVariants}>
                <h2 className="text-2xl font-bold glow-text mb-6">
                  Achievements Unlocked
                </h2>
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  {achievements.map((achievement) => (
                    <motion.div
                      key={achievement.id}
                      whileHover={{ scale: 1.1 }}
                      className="cosmic-card text-center py-6 group cursor-pointer"
                    >
                      <Trophy className="w-8 h-8 text-accent mx-auto mb-3 group-hover:animate-bounce" />
                      <p className="font-semibold text-sm text-foreground">
                        {achievement.title}
                      </p>
                      <p className="text-xs text-foreground/50 mt-2">
                        {new Date(achievement.unlockedAt).toLocaleDateString()}
                      </p>
                    </motion.div>
                  ))}
                </div>
              </motion.div>
            )}
          </motion.div>
        </main>
      </div>
    </div>
  );
}
