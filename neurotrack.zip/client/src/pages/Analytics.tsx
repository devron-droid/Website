import { motion } from "framer-motion";
import {
  LineChart,
  Line,
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
  PieChart,
  Pie,
  Cell,
} from "recharts";
import { Card } from "@/components/ui/card";
import { useAuth } from "@/_core/hooks/useAuth";

// Mock data - replace with real data from API
const weeklyData = [
  { day: "Mon", completed: 5, total: 6 },
  { day: "Tue", completed: 4, total: 6 },
  { day: "Wed", completed: 6, total: 6 },
  { day: "Thu", completed: 5, total: 6 },
  { day: "Fri", completed: 6, total: 6 },
  { day: "Sat", completed: 3, total: 6 },
  { day: "Sun", completed: 4, total: 6 },
];

const categoryData = [
  { name: "Health", value: 35, color: "#06b6d4" },
  { name: "Productivity", value: 25, color: "#0ea5e9" },
  { name: "Mindfulness", value: 20, color: "#6366f1" },
  { name: "Fitness", value: 20, color: "#8b5cf6" },
];

const xpData = [
  { week: "Week 1", xp: 120 },
  { week: "Week 2", xp: 180 },
  { week: "Week 3", xp: 150 },
  { week: "Week 4", xp: 220 },
];

export default function Analytics() {
  const { user } = useAuth();

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: {
      opacity: 1,
      y: 0,
      transition: { duration: 0.5 },
    },
  };

  return (
    <div className="cosmic-bg min-h-screen py-12">
      <div className="fixed inset-0 pointer-events-none">
        <div className="nebula-glow w-96 h-96 top-10 left-10 animate-pulse" />
        <div className="nebula-glow w-96 h-96 bottom-20 right-20 animate-pulse" style={{ animationDelay: "1s" }} />
      </div>

      <div className="relative z-10 container">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-12"
        >
          <h1 className="text-4xl font-bold glow-text-lg mb-2">Analytics Dashboard</h1>
          <p className="text-foreground/60">Track your progress and growth over time</p>
        </motion.div>

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {/* Weekly Completion Chart */}
          <motion.div variants={itemVariants} initial="hidden" animate="visible">
            <Card className="cosmic-card p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                Weekly Completion Rate
              </h2>
              <ResponsiveContainer width="100%" height={300}>
                <BarChart data={weeklyData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,217,255,0.1)" />
                  <XAxis stroke="rgba(255,255,255,0.6)" />
                  <YAxis stroke="rgba(255,255,255,0.6)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(10, 14, 39, 0.9)",
                      border: "1px solid rgba(0, 217, 255, 0.3)",
                      borderRadius: "8px",
                    }}
                  />
                  <Legend />
                  <Bar dataKey="completed" fill="#06b6d4" name="Completed" />
                  <Bar dataKey="total" fill="rgba(0, 217, 255, 0.2)" name="Total" />
                </BarChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>

          {/* Category Distribution */}
          <motion.div
            variants={itemVariants}
            initial="hidden"
            animate="visible"
            transition={{ delay: 0.1 }}
          >
            <Card className="cosmic-card p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                Habits by Category
              </h2>
              <ResponsiveContainer width="100%" height={300}>
                <PieChart>
                  <Pie
                    data={categoryData}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, value }) => `${name}: ${value}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {categoryData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(10, 14, 39, 0.9)",
                      border: "1px solid rgba(0, 217, 255, 0.3)",
                      borderRadius: "8px",
                    }}
                  />
                </PieChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>

          {/* XP Growth Chart */}
          <motion.div
            variants={itemVariants}
            initial="hidden"
            animate="visible"
            transition={{ delay: 0.2 }}
            className="lg:col-span-2"
          >
            <Card className="cosmic-card p-6">
              <h2 className="text-xl font-semibold text-foreground mb-6">
                XP Growth Over Time
              </h2>
              <ResponsiveContainer width="100%" height={300}>
                <LineChart data={xpData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="rgba(0,217,255,0.1)" />
                  <XAxis stroke="rgba(255,255,255,0.6)" />
                  <YAxis stroke="rgba(255,255,255,0.6)" />
                  <Tooltip
                    contentStyle={{
                      backgroundColor: "rgba(10, 14, 39, 0.9)",
                      border: "1px solid rgba(0, 217, 255, 0.3)",
                      borderRadius: "8px",
                    }}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="xp"
                    stroke="#06b6d4"
                    strokeWidth={3}
                    dot={{ fill: "#06b6d4", r: 6 }}
                    activeDot={{ r: 8 }}
                    name="XP Earned"
                  />
                </LineChart>
              </ResponsiveContainer>
            </Card>
          </motion.div>

          {/* Stats Cards */}
          <motion.div
            variants={itemVariants}
            initial="hidden"
            animate="visible"
            transition={{ delay: 0.3 }}
            className="lg:col-span-2 grid grid-cols-2 md:grid-cols-4 gap-4"
          >
            <Card className="cosmic-card text-center py-6">
              <p className="text-foreground/60 text-sm">Total Days Tracked</p>
              <p className="text-3xl font-bold glow-text mt-2">{user?.totalDaysTracked || 0}</p>
            </Card>
            <Card className="cosmic-card text-center py-6">
              <p className="text-foreground/60 text-sm">Total XP Earned</p>
              <p className="text-3xl font-bold glow-text mt-2">{user?.totalXPEarned || 0}</p>
            </Card>
            <Card className="cosmic-card text-center py-6">
              <p className="text-foreground/60 text-sm">Current Level</p>
              <p className="text-3xl font-bold glow-text mt-2">{user?.currentLevel || 1}</p>
            </Card>
            <Card className="cosmic-card text-center py-6">
              <p className="text-foreground/60 text-sm">Consistency</p>
              <p className="text-3xl font-bold glow-text mt-2">{user?.consistencyPercentage || 0}%</p>
            </Card>
          </motion.div>
        </div>
      </div>
    </div>
  );
}
