import { useState } from "react";
import { motion } from "framer-motion";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { format, startOfMonth, endOfMonth, eachDayOfInterval, isSameMonth } from "date-fns";

type DayStatus = "completed" | "missed" | "not-required" | "pending";

interface CalendarDay {
  date: Date;
  status: DayStatus;
  habitsCompleted: number;
  habitsTotal: number;
}

export default function Calendar() {
  const [currentDate, setCurrentDate] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState<Date | null>(null);

  // Mock data - replace with real data from API
  const getDayStatus = (date: Date): CalendarDay => {
    const day = date.getDate();
    const random = Math.random();

    let status: DayStatus;
    if (random > 0.7) status = "completed";
    else if (random > 0.4) status = "missed";
    else if (random > 0.2) status = "pending";
    else status = "not-required";

    return {
      date,
      status,
      habitsCompleted: Math.floor(Math.random() * 6),
      habitsTotal: 6,
    };
  };

  const monthStart = startOfMonth(currentDate);
  const monthEnd = endOfMonth(currentDate);
  const daysInMonth = eachDayOfInterval({ start: monthStart, end: monthEnd });

  const previousMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() - 1));
  };

  const nextMonth = () => {
    setCurrentDate(new Date(currentDate.getFullYear(), currentDate.getMonth() + 1));
  };

  const getStatusColor = (status: DayStatus) => {
    switch (status) {
      case "completed":
        return "bg-gradient-to-br from-green-500 to-emerald-600";
      case "missed":
        return "bg-gradient-to-br from-red-500 to-rose-600";
      case "pending":
        return "bg-card/60 border border-primary/30";
      case "not-required":
        return "bg-card/30 opacity-50";
    }
  };

  const getStatusLabel = (status: DayStatus) => {
    switch (status) {
      case "completed":
        return "✓ Completed";
      case "missed":
        return "✗ Missed";
      case "pending":
        return "⏳ Pending";
      case "not-required":
        return "— Not Required";
    }
  };

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.05,
      },
    },
  };

  const itemVariants = {
    hidden: { opacity: 0, scale: 0.8 },
    visible: {
      opacity: 1,
      scale: 1,
      transition: { duration: 0.3 },
    },
  };

  return (
    <div className="cosmic-bg min-h-screen py-12">
      <div className="fixed inset-0 pointer-events-none">
        <div className="nebula-glow w-96 h-96 top-10 left-10 animate-pulse" />
        <div className="nebula-glow w-96 h-96 bottom-20 right-20 animate-pulse" style={{ animationDelay: "1s" }} />
      </div>

      <div className="relative z-10 container max-w-4xl">
        <motion.div
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          className="mb-8"
        >
          <h1 className="text-4xl font-bold glow-text-lg mb-2">Habit Calendar</h1>
          <p className="text-foreground/60">Track your daily progress and streaks</p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 20 }}
          className="space-y-8"
        >
          {/* Calendar header */}
          <Card className="cosmic-card p-6">
            <div className="flex justify-between items-center mb-8">
              <Button
                variant="outline"
                size="sm"
                onClick={previousMonth}
                className="border-primary/30"
              >
                <ChevronLeft className="w-4 h-4" />
              </Button>
              <h2 className="text-2xl font-bold glow-text">
                {format(currentDate, "MMMM yyyy")}
              </h2>
              <Button
                variant="outline"
                size="sm"
                onClick={nextMonth}
                className="border-primary/30"
              >
                <ChevronRight className="w-4 h-4" />
              </Button>
            </div>

            {/* Day labels */}
            <div className="grid grid-cols-7 gap-2 mb-4">
              {["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat"].map((day) => (
                <div
                  key={day}
                  className="text-center text-sm font-semibold text-foreground/60"
                >
                  {day}
                </div>
              ))}
            </div>

            {/* Calendar grid */}
            <motion.div
              variants={containerVariants}
              initial="hidden"
              animate="visible"
              className="grid grid-cols-7 gap-2"
            >
              {daysInMonth.map((date) => {
                const dayData = getDayStatus(date);
                const isSelected = selectedDate?.toDateString() === date.toDateString();

                return (
                  <motion.button
                    key={date.toISOString()}
                    variants={itemVariants}
                    whileHover={{ scale: 1.1 }}
                    onClick={() => setSelectedDate(date)}
                    className={`aspect-square rounded-lg p-2 transition-all ${getStatusColor(
                      dayData.status
                    )} ${isSelected ? "ring-2 ring-accent" : ""}`}
                  >
                    <div className="flex flex-col items-center justify-center h-full">
                      <span className="text-sm font-semibold text-foreground">
                        {date.getDate()}
                      </span>
                      <span className="text-xs text-foreground/60 mt-1">
                        {dayData.habitsCompleted}/{dayData.habitsTotal}
                      </span>
                    </div>
                  </motion.button>
                );
              })}
            </motion.div>

            {/* Legend */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4 mt-8 pt-8 border-t border-primary/10">
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-gradient-to-br from-green-500 to-emerald-600" />
                <span className="text-sm text-foreground/60">Completed</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-gradient-to-br from-red-500 to-rose-600" />
                <span className="text-sm text-foreground/60">Missed</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-card/60 border border-primary/30" />
                <span className="text-sm text-foreground/60">Pending</span>
              </div>
              <div className="flex items-center gap-2">
                <div className="w-4 h-4 rounded bg-card/30 opacity-50" />
                <span className="text-sm text-foreground/60">Not Required</span>
              </div>
            </div>
          </Card>

          {/* Selected day details */}
          {selectedDate && (
            <motion.div
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-4"
            >
              <h3 className="text-xl font-bold glow-text">
                {format(selectedDate, "EEEE, MMMM d, yyyy")}
              </h3>

              <Card className="cosmic-card p-6">
                <div className="space-y-4">
                  <div>
                    <p className="text-foreground/60 mb-2">Status</p>
                    <p className="text-lg font-semibold text-accent">
                      {getStatusLabel(getDayStatus(selectedDate).status)}
                    </p>
                  </div>

                  <div>
                    <p className="text-foreground/60 mb-2">Habits Completed</p>
                    <p className="text-lg font-semibold glow-text">
                      {getDayStatus(selectedDate).habitsCompleted} /{" "}
                      {getDayStatus(selectedDate).habitsTotal}
                    </p>
                  </div>

                  <div className="pt-4 border-t border-primary/10">
                    <p className="text-foreground/60 mb-3">Add Notes</p>
                    <textarea
                      placeholder="How did you feel today? Any challenges?"
                      className="w-full bg-card/60 border border-primary/30 rounded-lg p-3 text-foreground placeholder:text-foreground/40 focus:outline-none focus:border-primary/60"
                      rows={4}
                    />
                  </div>

                  <Button className="w-full bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-600 hover:to-blue-700">
                    Save Notes
                  </Button>
                </div>
              </Card>
            </motion.div>
          )}
        </motion.div>
      </div>
    </div>
  );
}
